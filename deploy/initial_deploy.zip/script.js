// import { CountUp } from 'CountUp.min.js';

// window.onload = function() {
//   var countUp = new CountUp('counter', 2000);
//   countUp.start();
// }

// window.onload = function() {
//   var countUp = new CountUp('counter2', 2000);
//   countUp.start();
// }

// window.onload = function() {
//   var countUp = new CountUp('counter3', 2000);
//   countUp.start();
// }

// window.onload = function() {
//   var countUp = new CountUp('counter4', 2000);
//   countUp.start();
// }

// var options = {
// 	useEasing: false,
// 	useGrouping: true,
// 	separator: ',',
// };

// var options2 = {
// 	useEasing: false,
// 	useGrouping: false,
// 	separator: '',
// };

// var metrics = new CountUp('counter', 0, 2009, 0, 1.5, options2);
// metrics.start();

// var metrics = new CountUp('counter2', 0, 11, 0, 1.5, options);
// metrics.start();

var animateHTML = function() {
  var elems,
      windowHeight
  
  var init = function() {
    elems = document.getElementsByClassName("hidden");
    windowHeight = window.innerHeight;
    _addEventHandlers();
  }
  
  var _addEventHandlers = function() {
      window.addEventListener("scroll", _checkPosition);
      window.addEventListener("resize", init)
  }
  var _checkPosition = function() {
    for ( var i = 0; i < elems.length; i++ ) {
      var posFromTop = elems[i].getBoundingClientRect().top;
      if ( posFromTop - windowHeight <= 0) { 
        elems[i].className = elems[i].className.replace( "hidden", "fadeIn");
      }
    }    
  }
  
  return {
    init: init
  }
}

animateHTML().init();

// var metrics = new CountUp('counter3', 0, 39, 0, 1.5, options);
// metrics.start();

// var metrics = new CountUp('counter4', 0, 43687000, 0, 1.5, options);
// metrics.start();
